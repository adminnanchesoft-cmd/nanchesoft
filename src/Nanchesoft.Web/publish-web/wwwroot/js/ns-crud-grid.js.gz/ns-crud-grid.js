window.nsCrudGrid = (() => {
    const instances = {};

    function pick(obj, camel, pascal, fallback = undefined) {
        if (!obj) return fallback;
        if (obj[camel] !== undefined) return obj[camel];
        if (obj[pascal] !== undefined) return obj[pascal];
        return fallback;
    }

    function getColumns(definition) {
        return pick(definition, "columns", "Columns", []);
    }

    function getRows(definition) {
        return pick(definition, "rows", "Rows", []);
    }

    function getKeyExpr(definition) {
        return pick(definition, "keyExpr", "KeyExpr", "Id");
    }

    function getCatalogKey(definition) {
        return pick(definition, "catalogKey", "CatalogKey", "catalog");
    }

    function getTitle(definition) {
        return pick(definition, "title", "Title", "Catálogo");
    }

    function getAllowCreate(definition) {
        return pick(definition, "allowCreate", "AllowCreate", true);
    }

    function getAllowUpdate(definition) {
        return pick(definition, "allowUpdate", "AllowUpdate", true);
    }

    function getAllowDelete(definition) {
        return pick(definition, "allowDelete", "AllowDelete", true);
    }

    function getNewUrl(definition) {
        return pick(definition, "newUrl", "NewUrl", null);
    }

    function getEditUrl(definition) {
        return pick(definition, "editUrl", "EditUrl", null);
    }

    function getMetadata(definition) {
        return pick(definition, "metadata", "Metadata", {});
    }

    function getMetadataArray(definition, key) {
        const metadata = getMetadata(definition);
        const value = metadata?.[key];
        return Array.isArray(value) ? value : [];
    }

    function getColumnValue(col, camel, pascal, fallback = undefined) {
        return pick(col, camel, pascal, fallback);
    }

    function getLookupItems(col) {
        return pick(col, "lookupItems", "LookupItems", []);
    }

    function getLookupItemValue(item, camel, pascal, fallback = undefined) {
        return pick(item, camel, pascal, fallback);
    }

    function normalizeLookupItem(x) {
        return {
            id: getLookupItemValue(x, "id", "Id", ""),
            name: getLookupItemValue(x, "name", "Name", ""),
            group: getLookupItemValue(x, "group", "Group", ""),
            color: getLookupItemValue(x, "color", "Color", ""),
            icon: getLookupItemValue(x, "icon", "Icon", ""),
            description: getLookupItemValue(x, "description", "Description", ""),
            code: getLookupItemValue(x, "code", "Code", ""),
            affectType: getLookupItemValue(x, "affectType", "AffectType", ""),
            isActive: getLookupItemValue(x, "isActive", "IsActive", true)
        };
    }

    function renderLookupVisual(container, item) {
        const wrapper = document.createElement("div");
        wrapper.className = item?.description || item?.affectType || item?.code ? "ns-lookup-card" : "ns-lookup-chip";
        const color = item?.color || "#64748b";
        const icon = item?.icon || "";
        const dot = document.createElement("span");
        dot.className = wrapper.className === "ns-lookup-card" ? "ns-lookup-card__dot" : "ns-lookup-chip__dot";
        dot.style.background = color;
        const text = document.createElement("span");
        text.className = wrapper.className === "ns-lookup-card" ? "ns-lookup-card__body" : "ns-lookup-chip__text";
        if (wrapper.className === "ns-lookup-card") {
            const title = document.createElement("span");
            title.className = "ns-lookup-card__title";
            title.textContent = `${icon ? icon + " " : ""}${item?.name || ""}`;
            const meta = document.createElement("span");
            meta.className = "ns-lookup-card__meta";
            meta.textContent = [item?.group, item?.affectType, item?.isActive === false ? "Inactivo" : "Activo"].filter(Boolean).join(" · ");
            const desc = document.createElement("span");
            desc.className = "ns-lookup-card__desc";
            desc.textContent = item?.description || "";
            text.append(title, meta);
            if (item?.description) text.append(desc);
        } else {
            text.textContent = `${icon ? icon + " " : ""}${item?.name || ""}`;
        }
        wrapper.title = item?.group ? `${item.group} · ${item.name}` : item?.name || "";
        wrapper.append(dot, text);
        container.appendChild(wrapper);
    }

    function getResultSuccess(result) {
        return pick(result, "success", "Success", false);
    }

    function getResultError(result) {
        return pick(result, "error", "Error", "Ocurrió un error.");
    }

    function getResultDefinition(result) {
        return pick(result, "definition", "Definition", null);
    }

    function getResultNewId(result) {
        return pick(result, "newId", "NewId", "");
    }

    function getResultAllItems(result) {
        return pick(result, "allItems", "AllItems", []);
    }

    function normalizeId(value) {
        return String(value ?? "").trim().toLowerCase();
    }

    function readAny(obj, names) {
        if (!obj) return undefined;
        for (const name of names) {
            if (obj[name] !== undefined) return obj[name];
        }
        return undefined;
    }

    function writeFormValue(form, fieldName, value) {
        if (!form || !fieldName) return;
        if (typeof form.updateData === "function") {
            form.updateData(fieldName, value ?? null);
        }

        const formData = form.option?.("formData") || {};
        formData[fieldName] = value ?? null;
        form.option?.("formData", formData);
    }

    function parseDateValue(value) {
        if (!value) return null;
        const date = value instanceof Date ? value : new Date(value);
        return Number.isNaN(date.getTime()) ? null : date;
    }

    function toNumber(value) {
        if (value === null || value === undefined || value === "") return null;
        const parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : null;
    }

    function ensurePopupStyles() {
        if (document.getElementById("ns-crud-grid-popup-style")) {
            return;
        }

        const style = document.createElement("style");
        style.id = "ns-crud-grid-popup-style";
        style.textContent = `
            .ns-crud-popup-wrapper .dx-overlay-content {
                max-height: 92vh !important;
            }
            .ns-crud-popup-wrapper .dx-popup-content {
                overflow-y: auto !important;
                padding-bottom: 12px;
            }
            .ns-crud-popup-wrapper .dx-popup-bottom {
                position: sticky;
                bottom: 0;
                background: #fff;
                border-top: 1px solid #e5e7eb;
                z-index: 5;
            }
            .ns-qc-plus-btn {
                flex-shrink: 0;
                width: 36px;
                height: 36px;
                border: 1px solid #cbd5e1;
                background: #f8fafc;
                border-radius: 8px;
                cursor: pointer;
                font-size: 20px;
                font-weight: 700;
                color: #1d4ed8;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: background .15s, border-color .15s;
                padding: 0;
                line-height: 1;
            }
            .ns-qc-plus-btn:hover {
                background: #eff6ff;
                border-color: #93c5fd;
            }
            .ns-qc-wrapper {
                display: flex;
                gap: 6px;
                align-items: center;
            }
            .ns-qc-wrapper > div:first-child {
                flex: 1;
                min-width: 0;
            }
        `;

        document.head.appendChild(style);
    }

    function showQuickCreateDialog(title, onSave) {
        const overlay = document.createElement("div");
        overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:10000;display:flex;align-items:center;justify-content:center;padding:16px;";

        const dialog = document.createElement("div");
        dialog.style.cssText = "background:#fff;border-radius:14px;padding:24px 28px;max-width:380px;width:100%;box-shadow:0 16px 48px rgba(0,0,0,.22);font-family:'Segoe UI',sans-serif;";

        dialog.innerHTML = [
            `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">`,
            `  <h3 style="margin:0;font-size:16px;font-weight:700;color:#0f172a;">${title}</h3>`,
            `  <button class="qc-x" style="background:none;border:none;font-size:22px;cursor:pointer;color:#94a3b8;line-height:1;">×</button>`,
            `</div>`,
            `<div class="qc-error" style="display:none;margin-bottom:12px;padding:8px 12px;border-radius:8px;background:#fff1f2;color:#991b1b;font-size:13px;border:1px solid #fecdd3;"></div>`,
            `<div style="margin-bottom:12px;">`,
            `  <label style="display:block;font-size:11px;font-weight:700;color:#475569;margin-bottom:4px;letter-spacing:.4px;text-transform:uppercase;">Código *</label>`,
            `  <input class="qc-code" type="text" style="width:100%;box-sizing:border-box;padding:8px 12px;border-radius:8px;border:1px solid #cbd5e1;font-size:14px;" autocomplete="off"/>`,
            `</div>`,
            `<div style="margin-bottom:20px;">`,
            `  <label style="display:block;font-size:11px;font-weight:700;color:#475569;margin-bottom:4px;letter-spacing:.4px;text-transform:uppercase;">Nombre *</label>`,
            `  <input class="qc-name" type="text" style="width:100%;box-sizing:border-box;padding:8px 12px;border-radius:8px;border:1px solid #cbd5e1;font-size:14px;" autocomplete="off"/>`,
            `</div>`,
            `<div style="display:flex;gap:10px;justify-content:flex-end;">`,
            `  <button class="qc-cancel" style="padding:8px 18px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;color:#475569;cursor:pointer;font-size:14px;">Cancelar</button>`,
            `  <button class="qc-save" style="padding:8px 18px;border-radius:8px;border:none;background:#1d4ed8;color:#fff;cursor:pointer;font-size:14px;font-weight:600;">Crear</button>`,
            `</div>`
        ].join("");

        overlay.appendChild(dialog);
        document.body.appendChild(overlay);

        const codeInput = dialog.querySelector(".qc-code");
        const nameInput = dialog.querySelector(".qc-name");
        const errorDiv  = dialog.querySelector(".qc-error");
        const saveBtn   = dialog.querySelector(".qc-save");
        const cancelBtn = dialog.querySelector(".qc-cancel");
        const xBtn      = dialog.querySelector(".qc-x");

        setTimeout(() => codeInput.focus(), 60);

        const close = () => { if (overlay.parentNode) document.body.removeChild(overlay); };
        cancelBtn.addEventListener("click", close);
        xBtn.addEventListener("click", close);
        overlay.addEventListener("click", e => { if (e.target === overlay) close(); });

        const doSave = async () => {
            const code = codeInput.value.trim();
            const name = nameInput.value.trim();
            if (!code || !name) {
                errorDiv.textContent = "Código y nombre son obligatorios.";
                errorDiv.style.display = "block";
                return;
            }
            saveBtn.disabled = true;
            saveBtn.textContent = "Guardando…";
            errorDiv.style.display = "none";
            try {
                await onSave(code, name);
                close();
            } catch (err) {
                errorDiv.textContent = err.message || "Error al crear el registro.";
                errorDiv.style.display = "block";
                saveBtn.disabled = false;
                saveBtn.textContent = "Crear";
            }
        };

        saveBtn.addEventListener("click", doSave);
        nameInput.addEventListener("keydown", e => { if (e.key === "Enter") doSave(); });
    }

    function disposeCrudGrid(containerId) {
        const current = instances[containerId];
        if (current?.grid) {
            try {
                current.grid.dispose();
            } catch {
            }
        }

        const host = document.getElementById(containerId);
        if (host) {
            host.innerHTML = "";
        }

        delete instances[containerId];
    }

    function renderCrudGrid(containerId, definition, dotNetRef) {
        ensurePopupStyles();
        disposeCrudGrid(containerId);

        const host = document.getElementById(containerId);
        if (!host) {
            throw new Error(`No se encontró el contenedor '${containerId}'.`);
        }

        if (typeof DevExpress === "undefined" || !DevExpress.ui || !DevExpress.ui.dxDataGrid) {
            throw new Error("DevExtreme no está cargado. Revisa App.razor.");
        }

        const grid = new DevExpress.ui.dxDataGrid(
            host,
            buildGridOptions(containerId, definition, dotNetRef)
        );

        instances[containerId] = {
            grid,
            definition,
            dotNetRef
        };
    }

    function buildGridOptions(containerId, definition, dotNetRef) {
        const columns = getColumns(definition);
        const rows = getRows(definition);
        const keyExpr = getKeyExpr(definition);
        const title = getTitle(definition);
        const catalogKey = getCatalogKey(definition);
        const popupWidth = Math.max(760, Math.min(window.innerWidth - 32, 1100));
        const popupHeight = Math.max(620, Math.min(window.innerHeight - 32, 900));
        const allowCreate = getAllowCreate(definition);
        const allowUpdate = getAllowUpdate(definition);
        const allowDelete = getAllowDelete(definition);
        const newUrl = getNewUrl(definition);
        const editUrl = getEditUrl(definition);

        const editableColumns = columns.filter(x =>
            getColumnValue(x, "visible", "Visible", true) !== false &&
            getColumnValue(x, "allowEditing", "AllowEditing", true) &&
            getColumnValue(x, "dataField", "DataField", "") !== keyExpr
        );

        return {
            dataSource: Array.isArray(rows) ? rows : [],
            keyExpr: keyExpr,
            showBorders: true,
            rowAlternationEnabled: true,
            hoverStateEnabled: true,
            columnAutoWidth: true,
            allowColumnResizing: true,
            columnResizingMode: "widget",
            columnFixing: { enabled: true },
            repaintChangesOnly: false,
            height: 660,

            sorting: { mode: "multiple" },
            filterRow: { visible: true, applyFilter: "auto" },
            headerFilter: { visible: true },
            filterPanel: { visible: true },
            searchPanel: {
                visible: true,
                width: 280,
                placeholder: "Buscar en todos los campos..."
            },
            groupPanel: { visible: true, emptyPanelText: "Arrastra una columna aquí para agrupar" },
            grouping: { autoExpandAll: true },
            selection: { mode: "single" },
            columnChooser: {
                enabled: true,
                mode: "select",
                title: "Columnas visibles",
                height: 400
            },
            export: { enabled: false },

            paging: { pageSize: 12 },
            pager: {
                visible: true,
                allowedPageSizes: [12, 20, 40, 100],
                showPageSizeSelector: true,
                showNavigationButtons: true,
                showInfo: true
            },

            stateStoring: {
                enabled: true,
                type: "localStorage",
                storageKey: `nanchesoft:${catalogKey}:grid-state:v6`
            },

            columns: buildColumns(columns, definition, dotNetRef),

            editing: {
                mode: "popup",
                allowAdding: allowCreate && !newUrl,
                allowUpdating: allowUpdate && !editUrl,
                allowDeleting: allowDelete,
                useIcons: true,
                popup: {
                    title: `${title} · captura`,
                    showTitle: true,
                    width: popupWidth,
                    height: popupHeight,
                    maxWidth: popupWidth,
                    maxHeight: popupHeight,
                    dragEnabled: false,
                    resizeEnabled: true,
                    wrapperAttr: { class: "ns-crud-popup-wrapper" },
                    onShown(e) {
                        configurePopupLayout(e.component);
                        const form = getPopupForm(e.component);
                        if (form) {
                            refreshDependentLookups(form, definition);
                            applyServiceNoteDefaults(form, definition, true);
                        }
                    }
                },
                form: {
                    colCount: 2,
                    labelLocation: "top",
                    items: buildFormItems(editableColumns, definition, dotNetRef),
                    onFieldDataChanged(e) {
                        refreshDependentLookups(e.component, definition);
                        applyServiceNoteDefaults(e.component, definition, false, e.dataField);
                    }
                }
            },

            toolbar: {
                items: [
                    {
                        location: "before",
                        template() {
                            const el = document.createElement("div");
                            el.className = "ns-grid-toolbar-title";
                            el.textContent = title;
                            return el;
                        }
                    },
                    ...(allowCreate && newUrl ? [{
                        location: "after",
                        widget: "dxButton",
                        options: {
                            text: "Nuevo",
                            icon: "add",
                            type: "success",
                            stylingMode: "contained",
                            onClick: () => dotNetRef.invokeMethodAsync("HandleNavigateTo", newUrl)
                        }
                    }] : allowCreate ? [{
                        name: "addRowButton",
                        location: "after",
                        showText: "always",
                        options: {
                            text: "Nuevo",
                            icon: "add",
                            type: "success",
                            stylingMode: "contained"
                        }
                    }] : []),
                    "searchPanel",
                    {
                        location: "after",
                        widget: "dxButton",
                        options: {
                            icon: "xlsxfile",
                            hint: "Exportar a Excel",
                            type: "default",
                            stylingMode: "outlined",
                            onClick: () => exportToExcel(containerId, title, catalogKey)
                        }
                    },
                    "columnChooserButton",
                    {
                        location: "after",
                        widget: "dxButton",
                        options: {
                            text: "Recargar",
                            icon: "refresh",
                            type: "default",
                            stylingMode: "contained",
                            onClick: async () => {
                                const result = await dotNetRef.invokeMethodAsync("HandleRefresh");
                                renderCrudGrid(containerId, result, dotNetRef);
                                notify("Catálogo recargado.", "success");
                            }
                        }
                    }
                ]
            },

            onInitNewRow(e) {
                const hasPascalActive = columns.some(x => getColumnValue(x, "dataField", "DataField", "") === "IsActive");
                const hasCamelActive = columns.some(x => getColumnValue(x, "dataField", "DataField", "") === "isActive");

                if (hasPascalActive) {
                    e.data.IsActive = true;
                }
                if (hasCamelActive) {
                    e.data.isActive = true;
                }

                applySingleLookupDefaults(e.data, columns, definition);
                if (catalogKey === "service-notes") {
                    if (!e.data.NoteDate) {
                        e.data.NoteDate = new Date();
                    }
                }
                if (catalogKey === "hr-work-schedules") {
                    e.data.Monday = true;
                    e.data.Tuesday = true;
                    e.data.Wednesday = true;
                    e.data.Thursday = true;
                    e.data.Friday = true;
                }
            },

            onEditingStart(e) {
                if (catalogKey === "service-notes") {
                    applySingleLookupDefaults(e.data, columns, definition);
                }
            },

            onSaving(e) {
                if (!e.changes || e.changes.length === 0) {
                    return;
                }

                e.cancel = true;
                const change = e.changes[0];
                e.promise = handleSave(containerId, dotNetRef, change);
            },

            noDataText: "No hay registros para mostrar."
        };
    }

    function buildColumns(columns, definition, dotNetRef) {
        const allowUpdate = getAllowUpdate(definition);
        const allowDelete = getAllowDelete(definition);
        const editUrl = getEditUrl(definition);
        const keyExpr = getKeyExpr(definition);
        const mapped = columns
            .filter(x => getColumnValue(x, "dataField", "DataField", "") !== keyExpr)
            .map(col => {
                const dataType = getColumnValue(col, "dataType", "DataType", "string");
                const useLookup = getColumnValue(col, "useLookup", "UseLookup", false);
                const lookupItems = getLookupItems(col);
                const dataField = getColumnValue(col, "dataField", "DataField", "");
                const showInGrid = getColumnValue(col, "showInGrid", "ShowInGrid", true) !== false;

                const dxColumn = {
                    dataField: dataField,
                    caption: getColumnValue(col, "caption", "Caption", ""),
                    dataType: mapDataType(dataType),
                    width: getColumnValue(col, "width", "Width", 160),
                    allowEditing: getColumnValue(col, "allowEditing", "AllowEditing", true),
                    allowFiltering: getColumnValue(col, "allowFiltering", "AllowFiltering", true),
                    allowSorting: getColumnValue(col, "allowSorting", "AllowSorting", true),
                    visible: showInGrid,
                    showInColumnChooser: showInGrid
                };

                if (String(dataType).toLowerCase() === "boolean") {
                    dxColumn.alignment = "center";
                }

                if (String(dataType).toLowerCase() === "number") {
                    dxColumn.format = { type: "fixedPoint", precision: 2 };
                }

                if (String(dataType).toLowerCase() === "date") {
                    dxColumn.format = "dd/MM/yyyy";
                }

                if (useLookup && Array.isArray(lookupItems) && lookupItems.length > 0) {
                    const normalizedLookupItems = lookupItems.map(normalizeLookupItem);
                    dxColumn.lookup = {
                        dataSource: normalizedLookupItems,
                        valueExpr: "id",
                        displayExpr: "name"
                    };
                    if (normalizedLookupItems.some(x => x.color || x.icon || x.group)) {
                        dxColumn.cellTemplate = function(container, options) {
                            const el = container instanceof HTMLElement ? container : container?.[0];
                            if (!el) return;
                            const item = normalizedLookupItems.find(x => x.id === options.value);
                            if (item) renderLookupVisual(el, item);
                            else el.textContent = options.displayValue || "";
                        };
                    }
                }

                return dxColumn;
            });

        const commandButtons = [];
        if (allowUpdate && editUrl) {
            commandButtons.push({
                hint: "Editar",
                icon: "edit",
                onClick(e) {
                    const key = e.row?.data?.[keyExpr];
                    if (key) dotNetRef.invokeMethodAsync("HandleNavigateTo", `${editUrl}/${key}`);
                }
            });
        } else if (allowUpdate) {
            commandButtons.push("edit");
        }
        if (allowDelete) commandButtons.push("delete");

        if (commandButtons.length > 0) {
            mapped.unshift({
                type: "buttons",
                caption: "Acciones",
                width: 96,
                minWidth: 96,
                fixed: true,
                fixedPosition: "left",
                alignment: "center",
                cssClass: "ns-grid-command-column",
                buttons: commandButtons
            });
        }

        return mapped;
    }

    function buildFormItems(editableColumns, definition, dotNetRef) {
        if (getCatalogKey(definition) !== "hr-incidents") {
            return editableColumns.map(col => buildFormItem(col, definition, dotNetRef));
        }

        const byField = new Map(editableColumns.map(col => [getColumnValue(col, "dataField", "DataField", ""), col]));
        const item = field => byField.has(field) ? buildFormItem(byField.get(field), definition, dotNetRef) : null;
        const group = (caption, cssClass, fields, colCount = 2) => ({
            itemType: "group",
            caption,
            cssClass,
            colCount,
            colSpan: 2,
            items: fields.map(item).filter(Boolean)
        });

        return [
            group("Datos principales", "ns-form-group ns-form-group-primary", ["CompanyId", "BranchId", "EmployeeId", "PayrollIncidentTypeId", "IncidentDate", "Status"]),
            group("Nómina", "ns-form-group ns-form-group-blue", ["PayrollPeriodId"]),
            group("Importes", "ns-form-group ns-form-group-green", ["Quantity", "Amount"]),
            group("Observaciones", "ns-form-group ns-form-group-slate", ["Notes", "IsActive"])
        ].filter(x => x.items.length > 0);
    }

    function buildFormItem(col, definition, dotNetRef) {
        const caption = getColumnValue(col, "caption", "Caption", "");
        const dataField = getColumnValue(col, "dataField", "DataField", "");
        const dataType = getColumnValue(col, "dataType", "DataType", "string");
        const useLookup = getColumnValue(col, "useLookup", "UseLookup", false);
        const lookupItems = getLookupItems(col);
        const required = getColumnValue(col, "required", "Required", false);
        const quickCreateKey = getColumnValue(col, "quickCreateKey", "QuickCreateKey", null);

        const item = {
            dataField: dataField,
            label: { text: caption },
            colSpan: 1
        };

        if (useLookup && Array.isArray(lookupItems)) {
            const normalizedItems = lookupItems.map(normalizeLookupItem);

            item.editorType = "dxSelectBox";
            item.editorOptions = {
                dataSource: normalizedItems,
                valueExpr: "id",
                displayExpr: "name",
                searchEnabled: true,
                searchExpr: ["name", "group", "code", "affectType", "description"],
                showClearButton: !required,
                deferRendering: false,
                itemTemplate(itemData, _, itemElement) {
                    const el = itemElement instanceof HTMLElement ? itemElement : itemElement?.[0];
                    if (el) renderLookupVisual(el, itemData);
                }
            };

            if (quickCreateKey && dotNetRef) {
                item.editorOptions.buttons = [
                    "dropDown",
                    {
                        name: "quickCreate",
                        location: "after",
                        options: {
                            icon: "plus",
                            hint: `Crear ${caption}`,
                            stylingMode: "text",
                            onClick(e) {
                                const editor = e.component;
                                showQuickCreateDialog(`Nuevo: ${caption}`, async function(code, name) {
                                    const result = await dotNetRef.invokeMethodAsync("HandleQuickCreate", quickCreateKey, code, name);
                                    if (!getResultSuccess(result)) throw new Error(getResultError(result) || "Error al crear.");
                                    const allItems = getResultAllItems(result);
                                    const newItems = (allItems || []).map(normalizeLookupItem);
                                    if (col.LookupItems) col.LookupItems = allItems;
                                    if (col.lookupItems) col.lookupItems = allItems;
                                    editor.option("dataSource", newItems);
                                    const newId = getResultNewId(result);
                                    if (newId) editor.option("value", newId);
                                });
                            }
                        }
                    }
                ];
            }
        } else if (String(dataType).toLowerCase() === "boolean") {
            item.editorType = "dxSwitch";
        } else if (String(dataType).toLowerCase() === "number") {
            item.editorType = "dxNumberBox";
            item.editorOptions = {
                showSpinButtons: true,
                format: "#,##0.00",
                ...(getCatalogKey(definition) === "hr-incidents" && ["Quantity", "Amount"].includes(dataField) ? { min: 0 } : {})
            };
        } else if (String(dataType).toLowerCase() === "time") {
            item.editorType = "dxTextBox";
            item.editorOptions = {
                mask: "00:00",
                showMaskMode: "always",
                useMaskedValue: true,
                placeholder: "HH:mm"
            };
        }

        if (required) {
            item.validationRules = [
                {
                    type: "required",
                    message: `${caption} es obligatorio.`
                }
            ];
        }

        if (getCatalogKey(definition) === "hr-incidents" && ["Quantity", "Amount"].includes(dataField)) {
            item.validationRules = [
                ...(item.validationRules || []),
                {
                    type: "range",
                    min: 0,
                    message: `${caption} debe ser mayor o igual a 0.`
                }
            ];
        }

        return item;
    }

    function configurePopupLayout(popup) {
        if (!popup) return;
        const content = popup.content && popup.content();
        if (content) {
            content.style.overflowY = "auto";
            content.style.maxHeight = `${Math.max(420, Math.min(window.innerHeight - 140, 760))}px`;
        }
    }

    function getPopupForm(popup) {
        const content = popup?.content && popup.content();
        if (!content) return null;
        const formElement = content.querySelector(".dx-form");
        if (!formElement || !DevExpress?.ui?.dxForm?.getInstance) return null;
        return DevExpress.ui.dxForm.getInstance(formElement);
    }

    function setEditorDataSource(form, fieldName, items) {
        const editor = form.getEditor(fieldName);
        if (!editor) return;
        editor.option("dataSource", items);
    }

    function applySingleLookupDefaults(formData, columns, definition) {
        for (const column of columns) {
            if (!getColumnValue(column, "useLookup", "UseLookup", false)) continue;
            const fieldName = getColumnValue(column, "dataField", "DataField", "");
            if (!fieldName || formData[fieldName]) continue;
            const items = getLookupItems(column);
            if (Array.isArray(items) && items.length === 1) {
                formData[fieldName] = getLookupItemValue(items[0], "id", "Id", "");
            }
        }

        const companies = getMetadataArray(definition, "companies");
        if (!formData.CompanyId && formData.TenantId) {
            const tenantCompanies = companies.filter(x => normalizeId(x.tenantId) === normalizeId(formData.TenantId));
            if (tenantCompanies.length === 1) {
                formData.CompanyId = tenantCompanies[0].id;
            }
        }
    }

    function refreshDependentLookups(form, definition) {
        if (!form || getCatalogKey(definition) !== "service-notes") {
            return;
        }

        const data = form.option("formData") || {};
        const tenantId = normalizeId(data.TenantId);
        const companyId = normalizeId(data.CompanyId);

        const companies = getMetadataArray(definition, "companies");
        const customers = getMetadataArray(definition, "customers");
        const services = getMetadataArray(definition, "services");

        const companyOptions = companies
            .filter(x => !tenantId || normalizeId(x.tenantId) === tenantId)
            .map(x => ({ id: x.id, name: x.name }));
        setEditorDataSource(form, "CompanyId", companyOptions);

        if (!companyId && companyOptions.length === 1) {
            form.updateData("CompanyId", companyOptions[0].id);
        }

        const effectiveCompanyId = normalizeId((form.option("formData") || {}).CompanyId);
        const customerOptions = customers
            .filter(x => (!tenantId || normalizeId(x.tenantId) === tenantId) && (!effectiveCompanyId || normalizeId(x.companyId) === effectiveCompanyId))
            .map(x => ({ id: x.id, name: x.name }));
        setEditorDataSource(form, "CustomerId", customerOptions);

        const serviceOptions = services
            .filter(x => (!tenantId || normalizeId(x.tenantId) === tenantId) && (!effectiveCompanyId || normalizeId(x.companyId) === effectiveCompanyId))
            .map(x => ({ id: x.id, name: x.name }));
        setEditorDataSource(form, "ServiceCatalogItemId", serviceOptions);
    }

    function resolveHourlyRate(formData, definition) {
        const customerId = normalizeId(formData.CustomerId);
        const serviceCatalogItemId = normalizeId(formData.ServiceCatalogItemId);
        const noteDate = parseDateValue(formData.NoteDate);
        const tenantId = normalizeId(formData.TenantId);
        const companyId = normalizeId(formData.CompanyId);

        if (!serviceCatalogItemId) {
            return null;
        }

        const rates = getMetadataArray(definition, "rates");
        const matchingRates = rates
            .filter(x => x && x.isActive !== false)
            .filter(x => !customerId || normalizeId(x.customerId) === customerId)
            .filter(x => normalizeId(x.serviceCatalogItemId) === serviceCatalogItemId)
            .filter(x => !tenantId || normalizeId(x.tenantId) === tenantId)
            .filter(x => !companyId || normalizeId(x.companyId) === companyId)
            .filter(x => {
                if (!noteDate) return true;
                const from = parseDateValue(x.effectiveFrom);
                const to = parseDateValue(x.effectiveTo);
                if (from && noteDate < from) return false;
                if (to && noteDate > to) return false;
                return true;
            })
            .sort((a, b) => {
                const aDate = parseDateValue(a.effectiveFrom)?.getTime() ?? 0;
                const bDate = parseDateValue(b.effectiveFrom)?.getTime() ?? 0;
                return bDate - aDate;
            });

        const negotiatedRate = toNumber(matchingRates[0]?.rate);
        if (negotiatedRate !== null) {
            return negotiatedRate;
        }

        const services = getMetadataArray(definition, "services");
        const service = services.find(x => normalizeId(x.serviceCatalogItemId || x.id) === serviceCatalogItemId);
        return toNumber(service?.defaultRate);
    }

    function applyServiceNoteDefaults(form, definition, force = false, changedField = "") {
        if (!form || getCatalogKey(definition) !== "service-notes") {
            return;
        }

        const data = form.option("formData") || {};
        if (!data.NoteDate) {
            form.updateData("NoteDate", new Date());
        }

        const watchedFields = ["CustomerId", "ServiceCatalogItemId", "NoteDate", "CompanyId", "TenantId"];
        if (!force && changedField && !watchedFields.includes(changedField)) {
            return;
        }

        const rate = resolveHourlyRate(form.option("formData") || {}, definition);
        if (rate !== null) {
            form.updateData("HourlyRate", rate);
        }
    }

    function mapDataType(dataType) {
        switch (String(dataType || "").toLowerCase()) {
            case "boolean":
                return "boolean";
            case "number":
                return "number";
            case "date":
                return "date";
            case "datetime":
                return "datetime";
            default:
                return "string";
        }
    }

    async function handleSave(containerId, dotNetRef, change) {
        let result = null;
        const instance = instances[containerId];
        const definition = instance?.definition;

        try {
            switch (change.type) {
                case "insert": {
                    const insertData = mergeOpenFormData(change.data || {});
                    validateIncidentPayload(definition, insertData);
                    result = await dotNetRef.invokeMethodAsync("HandleInsert", insertData);
                    break;
                }

                case "update": {
                    const mergedData = {
                        ...(change.oldData || {}),
                        ...mergeOpenFormData(change.data || {})
                    };

                    validateIncidentPayload(definition, mergedData);
                    result = await dotNetRef.invokeMethodAsync(
                        "HandleUpdate",
                        String(change.key),
                        mergedData
                    );
                    break;
                }

                case "remove": {
                    result = await dotNetRef.invokeMethodAsync("HandleDelete", String(change.key));
                    break;
                }

                default:
                    return;
            }
        } catch (err) {
            notify(err?.message || "No se pudo guardar el registro.", "error");
            return;
        }

        const success = getResultSuccess(result);
        const error = getResultError(result);
        const resultDefinition = getResultDefinition(result);

        if (resultDefinition) {
            renderCrudGrid(containerId, resultDefinition, dotNetRef);
        }

        if (!success) {
            notify(error || "Ocurrió un error.", "error");
            return;
        }

        switch (change.type) {
            case "insert":
                notify("Registro creado correctamente.", "success");
                break;
            case "update":
                notify("Registro actualizado correctamente.", "success");
                break;
            case "remove":
                notify("Registro eliminado correctamente.", "success");
                break;
        }
    }

    function mergeOpenFormData(data) {
        const merged = { ...(data || {}) };

        const formElement = document.querySelector(".ns-crud-popup-wrapper .dx-form");
        const form = formElement && DevExpress?.ui?.dxForm?.getInstance
            ? DevExpress.ui.dxForm.getInstance(formElement)
            : null;
        const formData = form?.option?.("formData") || {};
        Object.assign(merged, formData);

        document.querySelectorAll(".ns-crud-popup-wrapper .ns-qc-wrapper[data-field]").forEach(wrapper => {
            const field = wrapper.dataset.field;
            const value = wrapper.dataset.value;
            if (field && value) {
                merged[field] = value;
            }
        });

        return merged;
    }

    function validateIncidentPayload(definition, data) {
        if (!definition || getCatalogKey(definition) !== "hr-incidents") {
            return;
        }

        normalizeIncidentPayload(data);

        const missing = [];
        if (!readAny(data, ["EmployeeId", "employeeId"])) missing.push("Colaborador");
        if (!readAny(data, ["PayrollIncidentTypeId", "payrollIncidentTypeId", "NomPayrollIncidentTypeId", "nomPayrollIncidentTypeId", "payroll_incident_type_id"])) missing.push("Tipo");
        if (!readAny(data, ["IncidentDate", "incidentDate"])) missing.push("Fecha");
        if (missing.length > 0) {
            throw new Error(`${missing.join(", ")} ${missing.length === 1 ? "es obligatorio" : "son obligatorios"}.`);
        }

        const quantity = toNumber(readAny(data, ["Quantity", "quantity"]));
        const amount = toNumber(readAny(data, ["Amount", "amount"]));
        if (quantity !== null && quantity < 0) throw new Error("Cantidad debe ser mayor o igual a 0.");
        if (amount !== null && amount < 0) throw new Error("Importe debe ser mayor o igual a 0.");
    }

    function normalizeIncidentPayload(data) {
        if (!data) return;
        const typeId = readAny(data, ["PayrollIncidentTypeId", "payrollIncidentTypeId", "NomPayrollIncidentTypeId", "nomPayrollIncidentTypeId", "payroll_incident_type_id"]);
        if (typeId) {
            data.PayrollIncidentTypeId = typeId;
            data.NomPayrollIncidentTypeId = typeId;
            data.payroll_incident_type_id = typeId;
        }
    }

    function pascalToCamel(value) {
        return value ? value.charAt(0).toLowerCase() + value.slice(1) : value;
    }

    function notify(message, type) {
        DevExpress.ui.notify({
            message,
            type,
            displayTime: 2600,
            width: 420
        });
    }

    function exportToExcel(containerId, title, catalogKey) {
        const inst = instances[containerId];
        if (!inst?.grid) return;
        if (!window.ExcelJS) { notify("ExcelJS no está disponible.", "error"); return; }
        const workbook = new window.ExcelJS.Workbook();
        workbook.creator = "Nanchesoft";
        workbook.created = new Date();
        const worksheet = workbook.addWorksheet(title.slice(0, 31));

        const logoRow = worksheet.addRow(["Nanchesoft ERP — " + title]);
        logoRow.font = { bold: true, size: 13, color: { argb: "FF1D4ED8" } };
        worksheet.addRow(["Exportado: " + new Date().toLocaleString("es-MX")]);
        worksheet.addRow([]);

        DevExpress.excelExporter.exportDataGrid({
            component: inst.grid,
            worksheet,
            topLeftCell: { row: 4, column: 1 },
            autoFilterEnabled: true,
            customizeCell({ gridCell, excelCell }) {
                if (gridCell.rowType === "header") {
                    excelCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1D4ED8" } };
                    excelCell.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 };
                    excelCell.alignment = { vertical: "middle", horizontal: "center", wrapText: true };
                    excelCell.border = {
                        top: { style: "thin", color: { argb: "FF1E40AF" } },
                        left: { style: "thin", color: { argb: "FF1E40AF" } },
                        bottom: { style: "thin", color: { argb: "FF1E40AF" } },
                        right: { style: "thin", color: { argb: "FF1E40AF" } }
                    };
                } else if (gridCell.rowType === "data") {
                    const bg = gridCell.rowIndex % 2 === 0 ? "FFF8FAFC" : "FFFFFFFF";
                    excelCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: bg } };
                    excelCell.font = { size: 9 };
                    excelCell.border = {
                        bottom: { style: "hair", color: { argb: "FFE2E8F0" } },
                        right: { style: "hair", color: { argb: "FFE2E8F0" } }
                    };
                } else if (gridCell.rowType === "group") {
                    excelCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFDBEAFE" } };
                    excelCell.font = { bold: true, size: 9, color: { argb: "FF1E40AF" } };
                }
            }
        }).then(() => {
            workbook.xlsx.writeBuffer().then(buffer => {
                const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = `${catalogKey}_${new Date().toISOString().slice(0, 10)}.xlsx`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                notify("Excel exportado.", "success");
            });
        }).catch(err => notify("Error al exportar: " + err.message, "error"));
    }

    return {
        renderCrudGrid,
        disposeCrudGrid
    };
})();
